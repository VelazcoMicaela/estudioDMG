<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Estudio DMG le informa que su cuenta ha sido activada en forma exitosa</title>

<link rel="stylesheet" href="css-placa/alta.css" type="text/css" media="screen" />
<link href="css-placa/estilosform.css" rel="stylesheet" type="text/css" />

	 </head>
	 <body>
		  <div id="container">
		    <div class="CLEAR">
		      <p><br />
		      </p>
		    </div>
            <div class="col-left">
  <div id="contenido2" class="content">
    <div class="sub-content3"></div>
  </div>
  <div id="contenido2" class="content">
    <div class="sub-content2">
      <div id="header-mesage">
        <h2>
          <img src="img-placa/1354848931_Warning.png" width="92" height="92" />Este sitio se encuentra en Construcción...</h2>
        <p align="justify"><span class="sub-content"><br />
          Para comunicarse con nosotros, por favor complete el siguiente formulario y le responderemos a la brevedad.</span></p>
        </div>
      </div>
  </div>
            </div>
            <div class="col-right">
              <div id="contenido" class="content">
              
                <div class="sub-content">
<img src="img-placa/envelope_mail_icon.png" name="mail" width="48" height="48" id="mail" align="bottom" />   
               <p id="mail-p">
                    <? // quita las 'www.' del principio del nombre de host (indiferente a mayúsculas)
$url = preg_replace('/^www\./i', '',$_SERVER['HTTP_HOST']);

?>
               
<a href="<? echo "mailto:info@".$_SERVER[SERVER_NAME]; ?>">
<? echo "info@".$url; ?>
</a>
               </p>
      

      
      
             <div class="clr"></div>
                  <div id="form" class="float-right">
                    <script type="text/javascript"> 
function validateNo(campo) { 
if ((campo.value!='')) {
       // alert('Password Correcta'); 
document.getElementById("No").innerHTML = 'Nombre y Apellido (*) <img src="img-placa/img04.png" border=0/>'; 
	   return true;
} else { // alert(errorMessage); 
document.getElementById("No").innerHTML = 'Nombre y Apellido <span class="dato">(*) Ingrese su Nombre y Apellido</span>';
	   return false;
//  campo.focus(); 
} } 
function validateMail(campo) { 
var RegExPattern = /[\w-\.]{3,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/; 
//
if (((campo.value.match(RegExPattern)) && campo.value!='' )) { 
document.getElementById("ml").innerHTML = 'eMail (*)  <img src="img-placa/img04.png" border=0/>';
	   return true;
} else { 
document.getElementById("ml").innerHTML = 'eMail <span class="dato">(*) La direccion de e-mail no es correcta</span>';
	   return false;
//    campo.focus(); 
} }
function validateNu(campo) { 
 var RegExPattern = "[0-9]";
if ((campo.value.match(RegExPattern)) && (campo.value!='')) {
// alert('Password Correcta'); 
document.getElementById("Nu").innerHTML = 'Tel&eacute;fono (*) <img src="img-placa/img04.png " border=0/>';
	   return true;

    } else { 
       // alert(errorMessage); 
	   document.getElementById("Nu").innerHTML = 'Tel&eacute;fono <span class="dato">(*) No es un n&uacute;mero de tel&eacute;fono v&aacute;lido</span>';
	   return false;

      //  campo.focus(); 
    } 
}

function validateNu2(campo) { 
if (campo.value=='') {
	return true
}
var RegExPattern = "[0-9]";
if ((campo.value.match(RegExPattern))) {
// alert('Password Correcta'); 
document.getElementById("Nu2").innerHTML = 'Tel&eacute;fono (*) <img src="img-placa/img04.png " border=0/>';
	   return true;

    } else { 
       // alert(errorMessage); 
	   document.getElementById("Nu2").innerHTML = 'Tel&eacute;fono <span class="dato">(*) No es un n&uacute;mero de tel&eacute;fono v&aacute;lido</span>';
	   return false;

      //  campo.focus(); 
    } 
} 
function funSubmit() {
	var isOk=true;

	if (!validateNo(document.form1.nombre)) {
		isOk=false;
	}
	if (!validateMail(document.form1.email)) {
		isOk=false;
	}
	if (!validateNu(document.form1.telefono)) {
		isOk=false;
	}
	
	if (!isOk) {
		alert("Por favor complete correctamente la informaci&oacute;n para poder procesar su solicitud.");
	} else {
		document.form1.submit();
	}
}
</script>
                      
                      
                      <? if($_REQUEST["enviado"]!="1"){?>
                   
                    
                      <div><span class="texto_form_contacto">
                        
                      <form name="form1" action="<?=$PHP_SELF;?>?enviado=1" method="post">
                        <div><span id="No" class="float-left "><strong>Nombre y Apellido </strong>(*)</span><? if (isset ($nombre)){echo $nombre;}else{echo "";} ?><br />
  <input name="nombre" class="texto1" id="No2" onblur="validateNo(this);" value="<? echo $_REQUEST["nombre"];?>" size="70" />
  <br />
                            
  <span id="Nu" class="float-left "><strong>Tel&eacute;fono</strong> (*)</span>  <? if (isset ($telefono)){echo $telefono;}else{echo "";} ?><br />
  <input name="telefono" class="campos_texto2" id="telefono" onblur="validateNu(this);" value="<? echo $_REQUEST["telefono"];?>" size="70" />
  <br>
  <span id="ml" class="float-left "><strong>eMail </strong>(*)</span><? if (isset ($email)){echo $email;}else{echo "";} ?><br>
                          <input  name="email" class="campos_texto2" id="email" onblur="validateMail(this);" value="<? echo $apellido=$_REQUEST["email"];?>" size="70" />
                            
                        </div>
                        <div>
  <br />
    <strong>Mensaje / Detalle</strong><br>
    <textarea name="mensaje" cols="75" rows="5" class="campos_texto" id="mensaje"><? echo $_REQUEST["mensaje"];?></textarea>
    <br>
    <br>
  
  <div class="bot">
    <input class="bot"  id="enviar" type="button" value="Enviar" name="Submit" onclick="javascript:funSubmit();"/>
  Los datos con (*) son obligatorios.</div>
  <div id="datos_obligatorios"></div>
                        </div>
                          
                          
  </form>
                        
  </span></div></div></div> 
                    
  <?
}else{
    $fecha = date("d-m-y H:i");
	if(isset( $_REQUEST["new"])) {
	$news="si";}
	else{$news="no";}
	//si queres cambiar el mail es este de aca abajo :)
	$mymail = "info@".$url;
	$subject = "Mail Consulta www.".$url;;
	$contenido =  "<br /><br /><strong> Nombre:</strong> ";
	$contenido .= htmlentities($_REQUEST["nombre"])."<br /><br /> <strong>Tel&eacute;fono: </strong>";
	$contenido .= htmlentities($_REQUEST["telefono"])."<br /><br /> <strong>Email:</strong> ";
	$contenido .= htmlentities($_REQUEST["email"])."<br /><br /> <strong> Mensaje:</strong> ";
	$contenido .= htmlentities($_REQUEST["mensaje"])."<br /><br />";		
	$contenido .= "<strong>El mensaje se escribi&oacute; el:</strong> ".$fecha;
	$header = "From:".$_REQUEST["email"]."\nReply-To:".$_REQUEST["email"]."\n";
	$header .= "X-Mailer:PHP/".phpversion()."\n";
	$header .= "Mime-Version: 1.0\n";
	$header .= "Content-type: text/html; charset=iso-8859-1\r\n";
mail($mymail, $subject, utf8_decode($contenido) ,$header);
	
	$fecha = date("d-m-y H:i");

	
	

	
?>
                    
                    
                    
  <div id="texto_contacto1">
  <div class="texto_contacto2"><br />
    
  <div class="destacado_contacto">
    <strong>Gracias <? echo $_REQUEST["nombre"];?>.</strong><br />
    Su Consulta ha sido enviada. Le responderemos a la brevedad.
    
  </div>
  </div>
  </div>
  <? } ?>
  </div>
                  
            </div>
     </div>
            </div>
			   <br clear="all" />
			   <div id="pie">
                 <div class="pie-left">
                   <p>&copy; <?=date('Y')?>  
<span><? echo "www.".$url; ?></span> - Todos los derechos reservados.</p>
                 </div>
                 
                 <div class="pie-right">
                   <p align="right"><a href="http://www.estudiodmg.com.ar" target="_parent">Diseño Web | Estudio DMG <img src="img-placa/habitadsrl.com.png" width="20" height="21" align="absmiddle" /></a></p>
                 </div>
          </div>
	 </body>
</html>