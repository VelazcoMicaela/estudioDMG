<?php
//---------------------------------  LIBRERIA FUNCIONES ------------------------------

 // Muestra fecha actual en espa�ol - formato salida: 29/03/2012
	    function fecha_hoy()  
    {  
        $today = date("d/m/Y");   
        return $today;    
    }  

//------------------------------------------------------------------
 // Fomatea fecha para insertar en mysql (yyyy-mm-dd)
function fechamysql($fecha){

		if (isset($fecha)){ // si esta definida

				if (!empty($fecha)) { // si no esta vacia 

				$mifecha = explode("/", $fecha);
				$lafecha=$mifecha[2]."-".$mifecha[1]."-".$mifecha[0];
				return $lafecha;
				} 
		} 
} 
//------------------------------------------------------------------
 // Fomatea fecha en espa�ol (dd-mm-yyyy)
function fechaespanol($fecha){

	if (isset($fecha)){ // si esta definida

				if (!empty($fecha)) { // si no esta vacia 

				$mifecha = explode("-", $fecha);
				$lafecha=$mifecha[2]."/".$mifecha[1]."/".$mifecha[0];
				return $lafecha;
			} 
	} 
} 
//------------------------------------------------------------------

//VAL_FILTRADO: recibe una variable y desinfecta contra ataques injection y XSS.
function VAL_FILTRADO($mivar) { 


		if (isset($mivar) and !empty($mivar)) {
		
		$mivar = trim($mivar);
		$mivar = htmlspecialchars($mivar);
		$mivar = htmlentities($mivar);
		$mivar = strip_tags($mivar);
		$mivar=addslashes($mivar);
		$peligros = array("x00","x1a","benchmark","column_name","join","union","all","table","table_name","information_schema","database","/","=","drop", "script", "%","java", "xp_cmdshell","user", "where","insert","show","update","delete","select","<",">",";","'","javascript", "vbscript", "expression", "applet", "meta", "xml", "blink", "link", "style","embed", "object", "iframe", "frame", "frameset", "ilayer", "layer", "bgsound", "title", "base","onabort", "onactivate", "onafterprint", "onafterupdate", "onbeforeactivate", "onbeforecopy", "onbeforecut", "onbeforedeactivate", "onbeforeeditfocus", "onbeforepaste", "onbeforeprint", "onbeforeunload", "onbeforeupdate", "onblur","alert", "onbounce", "oncellchange", "onchange", "onclick", "oncontextmenu", "oncontrolselect", "oncopy", "oncut", "ondataavailable", "ondatasetchanged", "ondatasetcomplete", "ondblclick", "ondeactivate", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "onerror", "onerrorupdate", "onfilterchange", "onfinish", "onfocus", "onfocusin", "onfocusout", "onhelp", "onkeydown", "onkeypress", "onkeyup", "onlayoutcomplete", "onload", "onlosecapture", "onmousedown", "onmouseenter", "onmouseleave", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onmove", "onmoveend", "onmovestart", "onpaste", "onpropertychange", "onreadystatechange", "onreset", "onresize", "onresizeend", "onresizestart", "onrowenter", "onrowexit", "onrowsdelete", "onrowsinserted", "onscroll", "onselect", "onselectionchange", "onselectstart", "onstart", "onstop", "onsubmit", "onunload","select",chr(92),"order by","concat","if","null","==","--","current_user","root","mysql","like","true","false","privileged","schema_name","information_schema","schemata","database","@@","hostname","version","separator","char", "case","when","load","file","into","fwrite","localhost","outfile","values","null","~","#","from","is not null","is not","is null","% or mod","binary","between","||","regexp","rlike","xor","\N","password","pubs","model","msdb","tempdb","northwind","db_name","sysdatabases","master","begin","declare","set","waitfor","delay","openrowset","sp_configure","show","shell","create","configure","execmd","execute","procedures","sp_password","|","alert","window","function","load","getelement","get","location","onclick","href",".php",".asp",".jsp","escape","cookie","_session","setinterval","style","<!--","-->","esapi","encoder","json","data","<%","%>","<?","?>","request","ftp","union","waitfor","abs","ascii","base64","bin","cast","chr","char","charset","collation","concat","conv","convert","count","curdate","database","date","decode","diff","distinct","elt","encode","encrypt","extract","field","_file","floor","format","hex","if","inner","insert","instr","interval","join","lcase","left","length","load_file","locate","lock","log","lower","lpad","ltrim","max","md5","mid","mod","name","now","null","ord","password","position","quote","rand","repeat","replace","reverse","right","rlike","round","row_count","rpad","rtrim","_set","schema","select","sha1","sha2","sleep","serverproperty","soundex","space","strcmp","substr","substr_index","substring","sum","time","trim","truncate","ucase","unhex","upper","_user","user","values","varchar","version","while","ws","xor");				
		
			$mivar = str_ireplace($peligros,"", $mivar); 			

		} else {
			
			$mivar=null;

		}
			
		return $mivar;

	 } 

//------------------------------------------------------------------
?>