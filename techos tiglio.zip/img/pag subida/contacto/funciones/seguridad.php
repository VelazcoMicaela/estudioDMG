<?php
session_start();$_SESSION['okform']=1;
//--------------------------------------------------
function ale1($num){
		$ca = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"; 
		$cadena = ""; 
		for($i=0;$i<$num;$i++)
		{
			$cadena .= substr($ca,rand(0,strlen($ca)),1); 
		}
		return $cadena;
}
//--------------------------------------------------
$pa1=sha1($_SERVER["SERVER_NAME"]);
$age1=ale1(12); //invalido
$age2=ale1(7); //invalido
$spa1=substr($pa1, 0, 20);
$spa2=substr($pa1, 20, 40);
$fin1=$age1.$spa1.$age2.$spa2;
//--------------------------------------------------
?>
