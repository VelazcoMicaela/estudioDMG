<?php
session_start();
$_SESSION['okform']=1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Formulario de Contacto</title>
<style> 
p {font-size: 14px; font-family:Arial, Helvetica, sans-serif;}
</style>
</head>

<body>
<center> 
<p> 
Muchas gracias por su consulta, en breve nos comunicaremos con usted. </p>
  </center>
    


</body>
</html>
