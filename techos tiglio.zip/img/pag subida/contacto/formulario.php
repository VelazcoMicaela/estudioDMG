<?php
include_once "funciones/seguridad.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Formulario de Contacto</title>
<link rel="stylesheet" type="text/css" href="css/estilo.css" />
<link rel="stylesheet" href="css/standard.css" type="text/css" />
<link rel="stylesheet" href="css/test.css" type="text/css" />
<link rel="stylesheet" href="css/validation.css" type="text/css" />

<script type="text/javascript" src="js/prototype.js" ></script>
<script type="text/javascript" src="js/livevalidation_prototype.js"></script>
<script type="text/javascript">
    var createHtmlMessageDiv = function(scope){
    var div = document.createElement('div');
    div.innerHTML = scope.message;
    return div;
	}
	
	var myLiveValidationCallback = function(){
		this.insertMessage(createHtmlMessageDiv(this));
		this.addFieldClass();
	}
  </script>
</head>

<body>
<form action="formulariopro.php" method="POST">
	<label for="nombre">Nombre y Apellido</label><br />
	<input type="text" name="nombre" id="f2"/ maxlength="35">
	<input type="hidden" name="c" value="<?=$fin1;?>">
  
    <br /><br />

    <label for="telefono">Telefono</label><br />
	<input type="text" name="telefono" id="f8"  maxlength="18"/>

    <br /><br />

    <label for="email">Email</label><br />
	<input id="f20" type="text" name="email"  maxlength="45"/>

    <br /><br />

    <label for="mensaje">Mensaje</label><br />
	<textarea id="f12" name="mensaje"></textarea>
    <script type="text/javascript">
			var f12 = new LiveValidation( 'f12', {onlyOnSubmit: true } );
      		f12.add( Validate.Presence );
			f12.add( Validate.Length, {minimum: 10} );
	  </script> 

    <br /><br /> 
    <input type="submit" value="ENVIAR" />
    
</form>

<script type="text/javascript">

	var f2 = new LiveValidation('f2', {onlyOnSubmit: true } );
	f2.add(Validate.Length, { minimum: 5, maximum: 30 } );

	var f8 = new LiveValidation('f8', {onlyOnSubmit: true } );
	f8.add(Validate.Numericality, { minimum: 111111, maximum: 999999999999 } );

	var f20 = new LiveValidation('f20', {onlyOnSubmit: true } );
	f20.add(Validate.Email);
	
	var f12 = new LiveValidation('f12', {onlyOnSubmit: true } );
	f12.add(Validate.Length, { minimum: 10, maximum: 500 } );
	
</script>
</body>
</html>
