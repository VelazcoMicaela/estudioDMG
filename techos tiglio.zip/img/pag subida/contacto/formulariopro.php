<?php
session_start();
include_once "funciones/libreria_funciones.php";
//---------------------------------------------------------------------------------
//configuro para comparar la seguridad encriptada.
$pac3=sha1($_SERVER["SERVER_NAME"]);
//----------------------------------------------------------------------------------

if(isset($_SESSION['okform']) and $_SESSION['okform']==1){ 

			if ($_SERVER['REQUEST_METHOD'] == 'POST'){

						//----------SE RECIBEN LOS DATOS DEL FORMULARIO Y SE FILTRAN LOS DATOS QUE LLEGAN								

								if (isset($_POST["nombre"])==true)  {  $nombre=  VAL_FILTRADO($_POST["nombre"]); }  else {$nombre="";}
								if (isset($_POST["telefono"])==true) {  $telefono=  VAL_FILTRADO($_POST["telefono"]); } else {$telefono="";}
								if (isset($_POST["email"])==true)     {  $email=      VAL_FILTRADO($_POST["email"]); }     else {$email="";}
								if (isset($_POST["mensaje"])==true) {  $mensaje= VAL_FILTRADO($_POST["mensaje"]); } else {$mensaje="";}
								if (isset($_POST["c"])==true) {  $c= $_POST["c"]; } else {$c=null;}

								//comparo la seguridad hashing:
								if(isset($c)){										
								$spb1=substr($c, 12, 20);
								$spb2=substr($c, 39, 20);								
								$cfinal=$spb1.$spb2;

												if($cfinal===$pac3){ // si el token corresponde al hash, lo dejo pasar.

													//----------SE ENVIA EL EMAIL-------------------------------------------------------------------													
																			include_once "funciones/class.phpmailer.php";
																			$cuerpo = "<B>CONTACTO WEB:</B><br><br><B>Nombre: </B>".$nombre."<br><B>Email: </B> ".$email."<br><B>Telefono: </B>".$telefono."<br><br><B>Mensaje: </B> ".$mensaje."";

																				$mail = new PHPMailer();
																				$mail->IsSMTP(); 
																				$mail->Host = "mail.techostiglio.com.ar";
																				$mail->From = "consultas@techostiglio.com.ar"; // email direccion origen
																				$mail->FromName = "CONTACTO WEB";
																				$mail->Subject = "CONTACTO WEB--> ".$nombre."";
																				$mail->AltBody ="CONTACTO WEB--> ".$nombre.""; 
																				$mail->MsgHTML($cuerpo);
																				$mail->AddAddress("info@techostiglio.com.ar", "destino"); // direccion destino
																				$mail->SMTPAuth = true;
																				$mail->Username = "consultas@techostiglio.com.ar"; // direccion origen
																				$mail->Password = "w4&HVMxy%hPD"; // clave del email direccion origen
																				$mail->Send();
																				

														//----------AL TERMINAR SE REDIRECCIONA A LA PAGINA DE GRACIAS---------------------
														header("Location: gracias.php");
														exit;

												} else{
												
												//no se autentico el hashing
												header("Location: http://www.google.com.ar"); 
												exit;	
												
												} // fin if($cfinal===$pac3){

								} else {												
								//el token no se envio y no existe (c)
								header("Location: http://www.google.com.ar"); 
								exit;	
								}// fin if(isset($c)){	


				} ELSE {


					// SI EL METODO DE ENVIO NO ES POST, LO MANDO A GOOGLE.	
					header("Location: http://www.google.com.ar"); 
					exit;				
				}

// SI EL POSTEO NO ES DESDE ESTE MISMO SERVIDOR Y EL FORMULARIO DEBIDO, LO MANDO A GOOGLE
} else {
header("Location: http://www.google.com.ar"); 
exit;
}
?>
