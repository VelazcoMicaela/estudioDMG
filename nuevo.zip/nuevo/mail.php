<?php 

    $nombre=$_POST ['nombre'];
    $apellido=$_POST['apellido'];
    $email=$_POST['email'];
    $comentario=$_POST['comentario'];

    $remitente= "From: $nombre <$email>";
    $destino= 'velazcomicaela@gmail.com';
    $asunto= $nombre . 'Envio la sig consulta a traves de la web';

    $cuerpo = 'Nombre: ' . $nombre . "\r\n";
    $cuerpo .= 'Apellido: ' . $apellido . "\r\n";
    $cuerpo .= 'Email: ' . $email . "\r\n";
    $cuerpo .= 'Comentario:  ' . $comentario;

    echo ($destino);

    mail($destino, $asunto, $cuerpo, $remitente); // llega al dueño de la empresa q controla

    header('location:index.php?envio=ok#seccionContacto'); // #contacto funciona como un ancla

?>

   